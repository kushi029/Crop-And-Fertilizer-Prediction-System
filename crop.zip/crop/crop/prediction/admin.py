from django.contrib import admin
from .models import cropdata
admin.site.register(cropdata)

# Register your models here.
